function clicou(){
document.getElementById("agradecimento").innerHTML = "<b>Obrigado por Clicar</b>";
//console.log(document.getElementById("agradecimento"));
//  alert("Obrigado por clicar");
}
function redirecionar(){
  //window.open("https://globallabs.academy/");
  window.location.href="https://globallabs.academy/";
}
function trocar(elemento){
  //document.getElementById("mousemove").innerHTML="Obrigado por passar o mouse";
  elemento.innerHTML= "Obrigado por passar o mouse"
  //alert("trocar texto");
}
function voltar(elemento){
 //document.getElementById("mousemove").innerHTML="Passe o mouse aqui";
 elemento.innerHTML= "Passe o mouse aqui"
}
function load{
  alert("página carregada");

}
function funçãoChange(elemento){
  console.log(elemento.value)
}
/*var validar=0;

function validaIdade(idade){
  if (idade>=18){
    validar=true
  }else{
    validar=false
  }
  return validar;

}

var idade = prompt("Qual sua idade");
validaIdade(idade)
console.log(validar);
*/
//var lista = ["maçã", "pera", "laranja"];
//lista.push("uva");
//lista.pop();
//console.log(lista);
//var nome = " Poliana Bayerl Bettim ";
//var n1 = 5;
//var n2 = 3;
//var idade2= 10;
//alert( nome + " tem " + idade + " anos ");
//alert(idade + idade2)
//console.log(nome);
//console.log(n1*n2);
//console.log(frase.replace("Japão","Brasil"))
//alert(frase.replace("Japão", "Brasil"));